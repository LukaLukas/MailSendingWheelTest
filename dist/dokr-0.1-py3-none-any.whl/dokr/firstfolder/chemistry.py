def chemistry():
    print('this is chemistry')