def math():
    print('this is math')